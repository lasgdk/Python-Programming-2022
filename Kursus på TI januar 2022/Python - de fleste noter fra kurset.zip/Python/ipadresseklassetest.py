class IPadresse:
    def __init__(self, ipadresse):
        parts=ipadresse.split('.')
        if len(parts) != 4:
            raise ValueError("IP adresse skal være 4 dele med . imellem.")
        self.parts=[]
        for part in parts:
            partint = int(part)
            if 0 <= partint < 256:
                self.parts.append(partint)
            else:
                raise ValueError("Tallene skal være mellem 0 og 255")
    def __repr__(self):
        return f"{self.parts[0]}.{self.parts[1]}.{self.parts[2]}.{self.parts[3]}"
        
    def __gt__(self,other):
        return True

# ip1 = IPadresse("192.168.1.13")
# print(ip1)