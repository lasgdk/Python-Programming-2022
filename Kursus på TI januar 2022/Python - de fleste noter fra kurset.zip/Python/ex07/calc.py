from distutils.log import debug
import logging

logging.basicConfig(filename="minlogfil.txt", level=logging.DEBUG, format="%(asctime)s")

a = None
b = None

class SyttenFejlen(Exception):
     pass

logging.info("Starting up.. Time is??")
while True:
    try:
        if a == None:
            a = float(input("Skriv første tal: "))
        if b == None:
            b = float(input("Skriv andet tal: "))
        logging.debug(f"a er: {a}, b er: {b}")

        if a == 17 or b == 17:
            raise SyttenFejlen("17 er et dååårligt tal bare fordi")

        print("sum: "+str(a+b))
        print("difference: "+str(a-b))
        print("multiplication: "+str(a*b))
        print("division: "+str(a/b))

    except ValueError:
        logging.error("Ej brugeren skrev ikke tal ind..")
        print("Skriv kun heltal!")

    except ZeroDivisionError:
        print("Ikke dividere med 0! Retter dit dårlige tal til et godt tal nær 0 :-)")
        b = 2.2250738585072014e-308

    except SyttenFejlen:
        print("Ej, ikke 17.. Prøv igen")
        a = None
        b = None
    else:
        break
