class MyError(Exception):
    pass

try:
    pass
except:
    pass
