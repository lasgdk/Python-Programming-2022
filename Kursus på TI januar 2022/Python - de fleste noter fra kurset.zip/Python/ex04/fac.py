def fac(n):
    """Factorial function

    >>> fac(0)
    1
    >>> fac(5)
    120
    """
    pass

for n in range(101):
    print(n, fac(n))
