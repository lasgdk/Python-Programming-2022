num = 1
while True:
    # ...
    num = num + 1
