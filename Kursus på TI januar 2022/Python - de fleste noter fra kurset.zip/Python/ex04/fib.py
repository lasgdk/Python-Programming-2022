

def fib(n):
    if n < 2:
        return n
    else:
        return (fib(n-1)+fib(n-2))


for n in range(101):
    fibcur=[n, fib(n)]
    print(fibcur)


