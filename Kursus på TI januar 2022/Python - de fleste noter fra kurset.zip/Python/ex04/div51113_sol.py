num = 1
while True:
    if num % 5 == 0 and num % 11 == 0 and num % 13 == 0:
        print("found:", num)
        break
    num = num + 1
