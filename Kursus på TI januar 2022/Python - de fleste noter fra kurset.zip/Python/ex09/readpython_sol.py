with open("inputtext.txt", 'r') as f:
    for line in f:
        line = line.rstrip()
        if "python" in line.lower():
            print(line)