for n in range(1, 101):
    if False:
        print("boom!", end=", ")
    elif False:
        print("boom!", end=", ")
    else:
        print(n, end=", ")
