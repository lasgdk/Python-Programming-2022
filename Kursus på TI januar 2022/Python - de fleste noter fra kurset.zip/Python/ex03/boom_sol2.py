for n in range(1, 101):
    if n % 7 == 0:
        print("boom!", end=", ")
    elif '7' in str(n):
        print("boom!", end=", ")
    else:
        print(n, end=", ")
