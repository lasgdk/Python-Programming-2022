def mitmodultest1():
    print("Jeg er inde i et modul, jeg returnerer nu..")
    return