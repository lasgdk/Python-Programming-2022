import fibfac_sol2

print(fibfac_sol2.fac(10))
