"""This is an interesting file

   This has lots of meaning.
"""

def f1(x):
    """This is a wonderful function.

       x: This is an important parameter
    """

