max_y = 10
max_x = 10
for y in range(1, max_y + 1):
    for x in range(1, max_x + 1):
        print(x*y, end=" ")
    print()