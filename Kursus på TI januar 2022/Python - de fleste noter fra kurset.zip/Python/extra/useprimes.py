import primes as pr

print(pr.primes(100))
