import xlsxwriter

writer = xlsxwriter.Workbook("rolo.xlsx")
sheet = writer._add_sheet("people")
sheet.write("A1", "Hello")
writer.close()
