import yfinance
import talib
from matplotlib import pyplot as plt
data = yfinance.download('NFLX','2021-1-1','2022-1-31')
rsi = talib.RSI(data["Close"])

print(rsi)