import ipadresseklassetest
import pytest

def testinstans():
    ip1 = ipadresseklassetest.IPadresse("192.168.1.1")
    s=str(ip1)
    assert s == "192.168.1.1"

def testtooolong():
    with pytest.raises(ValueError) as err:
        ip1 = ipadresseklassetest.IPadresse("192.168.1.123.13")

def testoutofrange():
    with pytest.raises(ValueError) as err:
        ip1 = ipadresseklassetest.IPadresse("192.168.1.1234")

def testgt():
    assert False
