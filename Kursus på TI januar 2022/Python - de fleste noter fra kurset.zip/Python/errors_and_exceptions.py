
while True:
    try:
        x = int(input("Skriv et tal: ")) # Prøv at konvertere inputtet til en int. Hvis det ikke kan, så kastes en ValueError
        break # Breaker ud af while løkken
    except ValueError:
        print("Arh, det var ikke et tal!")
        
try:
    x= 1/0
except ZeroDivisionError:
    print("division med nul .-/")

try:
    x= 1/0
except ArithmeticError:
    print("mere division med nul .-/")

