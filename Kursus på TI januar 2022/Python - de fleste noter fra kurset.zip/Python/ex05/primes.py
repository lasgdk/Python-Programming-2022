def primes(limit):
    candlist = list(range(2, limit+1))
    primelist = []
    # ...
    return primelist

if __name__ == "__main__":
    print(primes(1000))
