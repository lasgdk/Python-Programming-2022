data = [
    {
        "name": "Adrian Smidth",
        "email": "adrian@aol.com",
        "tel": "11223344",
        "birthday": "1970-11-06"
    },
    {
        "name": "Ben Forrest",
        "email": "ben@yahoo.com",
        "tel": "22334455",
        "birthday": "1969-09-26"
    },
    {
        "name": "Charlie Wilson",
        "email": "charlie@gmail.com",
        "tel": "44332211",
        "birthday": "1983-03-17"
    },
]

def insert_person(data, name, email, tel, birthday):
    print("Inserting data in the rolodex regarding: "+name)
    person = {
        "name": name,
        "email": name,
        "tel": tel,
        "birthday": birthday,
    }
    data.append(person)
    

def list_persons(data):
    print("The content of the rolodex is: ")
    for person in data:
        print(f"{person['name']:20} {person['email']:20} {person['tel']:20} {person['birthday']:20}")
        # print(person)
    # pass

def find_person(data, search):
    print("Searching the rolodex for "+search)
    for person in data:
        if search in person["name"]:
            return person
        
    

def update_person(data, search, 
        name="", email="", tel="", birthday=""):
    print("Updating the follow entry in the rolodex if existing: "+search)
    for person in data:
        if search in person["name"]:
            if name:
                person["name"] = name
            if email:
                person["email"] = email
            if tel:
                person["tel"] = tel
            if birthday:
                person["birthday"] = birthday
        
def delete_person(data, search):
    print("Removing the following person from the rolodex (if found): "+search)
    for person in data:
        if search in person["name"]:
            print("Gotcha! Removing "+search)
            data.remove(person)
            break

if __name__ == "__main__":
    print()
    list_persons(data)
    print()
    insert_person(data, "Dennis Rover", "dennis@ofir.dk", "66778899", "1987-06-05")
    print()
    list_persons(data)
    print()
    print(find_person(data, "Dennis"))
    print()
    update_person(data, "Rover", email="dennis@email.dk")
    print()
    delete_person(data, "Ben")
    print()
    list_persons(data)
    print()
