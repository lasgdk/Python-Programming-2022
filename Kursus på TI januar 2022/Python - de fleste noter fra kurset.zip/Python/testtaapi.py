

APIKEY='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Imxhc2dAbGFzZy5kayIsImlhdCI6MTY0MzcyMzQ1MywiZXhwIjo3OTUwOTIzNDUzfQ.WEZlE9vxO6AvolhJfBTASWJXfiJ8chw7P7sqDOgi52w'


# https://api.taapi.io/rsi?secret=MY_SECRET&exchange=binance&symbol=BTC/USDT&interval=1h

import urllib.request, json 
with urllib.request.urlopen("https://api.taapi.io/rsi?secret=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Imxhc2dAbGFzZy5kayIsImlhdCI6MTY0MzcyMzQ1MywiZXhwIjo3OTUwOTIzNDUzfQ.WEZlE9vxO6AvolhJfBTASWJXfiJ8chw7P7sqDOgi52w&exchange=omcx&symbol=CARLB&interval=1h") as url:
    data = json.loads(url.read().decode())
    print(data)