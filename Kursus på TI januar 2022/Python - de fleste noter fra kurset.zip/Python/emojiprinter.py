

while True: 
    for i in range(128512,128519): 
        print (chr(i),end="")
