flat = True
if flat:
    print("Be careful")

if condition:
    pass
else:
    pass